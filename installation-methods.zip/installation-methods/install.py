#!/usr/bin/env python3
"""
DNS Manpower Management System - Installation Script (Python)
Author: Sethru Dineth (ItzSD)
GitHub: https://github.com/itzsd0811
"""

import os
import sys
import subprocess
import shutil
import getpass
from pathlib import Path

# Colors for output
class Colors:
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    NC = '\033[0m'  # No Color

def print_info(msg):
    print(f"{Colors.BLUE}[INFO]{Colors.NC} {msg}")

def print_success(msg):
    print(f"{Colors.GREEN}[SUCCESS]{Colors.NC} {msg}")

def print_warning(msg):
    print(f"{Colors.YELLOW}[WARNING]{Colors.NC} {msg}")

def print_error(msg):
    print(f"{Colors.RED}[ERROR]{Colors.NC} {msg}")

def display_credits():
    """Display credits from credits.txt"""
    print("\n")
    credits_file = Path("credits.txt")
    if credits_file.exists():
        with open(credits_file, 'r', encoding='utf-8') as f:
            print(f.read())
    else:
        print("=" * 56)
        print("  DNS Manpower Management System")
        print("  Developed by: Sethru Dineth (ItzSD)")
        print("  GitHub: https://github.com/itzsd0811")
        print("=" * 56)
    print("\n")
    import time
    time.sleep(2)

def check_root():
    """Check if running as root"""
    if os.geteuid() == 0:
        print_error("Please do not run as root. The script will use sudo when needed.")
        sys.exit(1)

def run_command(cmd, check=True, shell=False):
    """Run a shell command"""
    try:
        if isinstance(cmd, str) and not shell:
            cmd = cmd.split()
        result = subprocess.run(cmd, check=check, shell=shell, 
                              capture_output=True, text=True)
        return result
    except subprocess.CalledProcessError as e:
        print_error(f"Command failed: {' '.join(cmd) if isinstance(cmd, list) else cmd}")
        if check:
            sys.exit(1)
        return None

def check_command_exists(cmd):
    """Check if a command exists"""
    return shutil.which(cmd) is not None

def check_dependencies():
    """Check and install system dependencies"""
    print_info("Checking system dependencies...")
    
    required_commands = ['git', 'curl', 'node', 'npm', 'nginx', 'certbot']
    missing_deps = [cmd for cmd in required_commands if not check_command_exists(cmd)]
    
    if missing_deps:
        print_warning(f"Missing dependencies: {', '.join(missing_deps)}")
        print_info("Installing missing dependencies...")
        
        # Detect package manager
        if check_command_exists('apt-get'):
            run_command(['sudo', 'apt-get', 'update'])
            deps = missing_deps + ['build-essential']
            run_command(['sudo', 'apt-get', 'install', '-y'] + deps)
        elif check_command_exists('yum'):
            deps = missing_deps + ['gcc', 'gcc-c++', 'make']
            run_command(['sudo', 'yum', 'install', '-y'] + deps)
        elif check_command_exists('dnf'):
            deps = missing_deps + ['gcc', 'gcc-c++', 'make']
            run_command(['sudo', 'dnf', 'install', '-y'] + deps)
        else:
            print_error(f"Unsupported package manager. Please install: {', '.join(missing_deps)}")
            sys.exit(1)
    else:
        print_success("All dependencies are installed")

def clone_repository():
    """Clone the repository"""
    print_info("Cloning repository...")
    
    repo_dir = Path("Manpower-Management-System")
    if repo_dir.exists():
        print_warning("Directory already exists. Removing old installation...")
        shutil.rmtree(repo_dir)
    
    run_command(['git', 'clone', 'https://github.com/itzSD0811/Manpower-Management-System.git'])
    os.chdir(repo_dir)
    print_success("Repository cloned successfully")

def install_dependencies():
    """Install Node.js dependencies"""
    print_info("Installing Node.js dependencies...")
    
    # Install frontend dependencies
    print_info("Installing frontend dependencies...")
    run_command(['npm', 'install'])
    
    # Install backend dependencies
    server_dir = Path('server')
    if server_dir.exists():
        print_info("Installing backend dependencies...")
        os.chdir(server_dir)
        run_command(['npm', 'install'])
        os.chdir('..')
    
    print_success("Dependencies installed successfully")

def build_application():
    """Build the application for production"""
    print_info("Building application for production...")
    
    run_command(['npm', 'run', 'build'])
    
    if not Path('dist').exists():
        print_error("Build failed! dist directory not found")
        sys.exit(1)
    
    print_success("Application built successfully")

def setup_domain_ssl():
    """Setup domain and SSL certificate"""
    domain = input("Enter your domain name (leave blank if no domain): ").strip()
    
    if not domain:
        print_info("No domain provided. Skipping SSL setup.")
        return None
    
    email = input("Enter your email for Let's Encrypt: ").strip()
    
    if not email:
        print_error("Email is required for SSL certificate")
        return None
    
    print_info(f"Setting up SSL certificate for {domain}...")
    
    # Stop nginx if running
    run_command(['sudo', 'systemctl', 'stop', 'nginx'], check=False)
    
    # Generate SSL certificate
    result = run_command([
        'sudo', 'certbot', 'certonly', '--standalone',
        '-d', domain, '--email', email,
        '--agree-tos', '--non-interactive'
    ], check=False)
    
    if result and result.returncode != 0:
        print_error("SSL certificate generation failed")
        return None
    
    print_success("SSL certificate generated successfully")
    return domain

def configure_nginx(domain=None):
    """Configure Nginx web server"""
    if not domain:
        domain = input("Enter your domain name (leave blank for IP access): ").strip()
    
    nginx_config = Path("/etc/nginx/sites-available/manpower-manager")
    app_dir = os.getcwd()
    
    server_name = f"server_name {domain};" if domain else "server_name _;"
    
    ssl_config = ""
    listen_config = "listen 80;\n    listen [::]:80;"
    
    if domain and Path(f"/etc/letsencrypt/live/{domain}/fullchain.pem").exists():
        ssl_config = """
    ssl_certificate /etc/letsencrypt/live/{}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/{}/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;""".format(domain, domain)
        listen_config = "listen 80;\n    listen [::]:80;\n    listen 443 ssl http2;\n    listen [::]:443 ssl http2;"
    
    print_info("Configuring Nginx...")
    
    config_content = f"""server {{
    {listen_config}
    {server_name}
    {ssl_config}
    
    root {app_dir}/dist;
    index index.html;
    
    location / {{
        try_files $uri $uri/ /index.html;
    }}
    
    # API proxy
    location /api {{
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}}
"""
    
    # Write nginx config
    process = subprocess.Popen(['sudo', 'tee', str(nginx_config)], 
                              stdin=subprocess.PIPE, text=True)
    process.communicate(input=config_content)
    if process.returncode != 0:
        print_error("Failed to write nginx configuration")
        sys.exit(1)
    
    # Enable site
    enabled_link = Path("/etc/nginx/sites-enabled/manpower-manager")
    if enabled_link.exists() or enabled_link.is_symlink():
        enabled_link.unlink()
    enabled_link.symlink_to(nginx_config)
    
    # Remove default site
    default_site = Path("/etc/nginx/sites-enabled/default")
    if default_site.exists():
        default_site.unlink()
    
    # Test and reload nginx
    run_command(['sudo', 'nginx', '-t'])
    run_command(['sudo', 'systemctl', 'reload', 'nginx'])
    
    print_success("Nginx configured successfully")

def create_backend_service():
    """Create systemd service for backend"""
    print_info("Creating systemd service for backend...")
    
    service_file = Path("/etc/systemd/system/manpower-backend.service")
    app_dir = os.getcwd()
    user = getpass.getuser()
    
    # Check for ts-node
    node_exec = shutil.which('node')
    if check_command_exists('ts-node'):
        exec_start = f"{shutil.which('ts-node')} src/index.ts"
    else:
        exec_start = f"{node_exec} src/index.ts"
        print_warning("ts-node not found. Please compile TypeScript manually or install ts-node")
    
    service_content = f"""[Unit]
Description=DNS Manpower Management System Backend
After=network.target

[Service]
Type=simple
User={user}
WorkingDirectory={app_dir}/server
Environment=NODE_ENV=production
ExecStart={exec_start}
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
"""
    
    process = subprocess.Popen(['sudo', 'tee', str(service_file)], 
                              stdin=subprocess.PIPE, text=True)
    process.communicate(input=service_content)
    if process.returncode != 0:
        print_error("Failed to write systemd service file")
        sys.exit(1)
    
    run_command(['sudo', 'systemctl', 'daemon-reload'])
    run_command(['sudo', 'systemctl', 'enable', 'manpower-backend.service'])
    
    print_success("Backend service created and enabled")

def setup_autostart():
    """Setup auto-start on boot"""
    print_info("Setting up auto-start on boot...")
    
    run_command(['sudo', 'systemctl', 'enable', 'manpower-backend.service'])
    run_command(['sudo', 'systemctl', 'enable', 'nginx'])
    run_command(['sudo', 'systemctl', 'start', 'manpower-backend.service'])
    run_command(['sudo', 'systemctl', 'start', 'nginx'])
    
    print_success("Auto-start configured successfully")

def get_server_ip():
    """Get server IP address"""
    try:
        result = run_command(['hostname', '-I'], check=False)
        if result and result.returncode == 0:
            return result.stdout.strip().split()[0]
    except:
        pass
    return "localhost"

def main():
    """Main installation function"""
    os.system('clear')
    display_credits()
    
    print_info("Starting installation process...")
    
    check_root()
    check_dependencies()
    clone_repository()
    install_dependencies()
    build_application()
    domain = setup_domain_ssl()
    configure_nginx(domain)
    create_backend_service()
    setup_autostart()
    
    print_success("Installation completed successfully!")
    print()
    print_info("Application is running at:")
    if domain:
        print(f"  Frontend: https://{domain}")
    else:
        ip = get_server_ip()
        print(f"  Frontend: http://{ip}")
    print("  Backend API: http://localhost:3001")
    print()
    print_info("Useful commands:")
    print("  Check backend status: sudo systemctl status manpower-backend")
    print("  Restart backend: sudo systemctl restart manpower-backend")
    print("  View backend logs: sudo journalctl -u manpower-backend -f")
    print()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInstallation cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print_error(f"Installation failed: {str(e)}")
        sys.exit(1)

