#!/bin/bash

###############################################################################
# DNS Manpower Management System - Installation Script (Bash)
# Author: Sethru Dineth (ItzSD)
# GitHub: https://github.com/itzsd0811
###############################################################################

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print colored output
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Display credits
display_credits() {
    echo ""
    if [ -f "credits.txt" ]; then
        cat credits.txt
    else
        echo "========================================================"
        echo "  DNS Manpower Management System"
        echo "  Developed by: Sethru Dineth (ItzSD)"
        echo "  GitHub: https://github.com/itzsd0811"
        echo "========================================================"
    fi
    echo ""
    sleep 2
}

# Check if running as root
check_root() {
    if [ "$EUID" -eq 0 ]; then 
        print_error "Please do not run as root. The script will use sudo when needed."
        exit 1
    fi
}

# Check if required commands exist
check_dependencies() {
    print_info "Checking system dependencies..."
    
    local missing_deps=()
    
    for cmd in git curl node npm nginx certbot; do
        if ! command -v $cmd &> /dev/null; then
            missing_deps+=($cmd)
        fi
    done
    
    if [ ${#missing_deps[@]} -ne 0 ]; then
        print_warning "Missing dependencies: ${missing_deps[*]}"
        print_info "Installing missing dependencies..."
        
        # Detect package manager
        if command -v apt-get &> /dev/null; then
            sudo apt-get update
            sudo apt-get install -y ${missing_deps[@]} build-essential
        elif command -v yum &> /dev/null; then
            sudo yum install -y ${missing_deps[@]} gcc gcc-c++ make
        elif command -v dnf &> /dev/null; then
            sudo dnf install -y ${missing_deps[@]} gcc gcc-c++ make
        else
            print_error "Unsupported package manager. Please install: ${missing_deps[*]}"
            exit 1
        fi
    else
        print_success "All dependencies are installed"
    fi
}

# Clone repository
clone_repository() {
    print_info "Cloning repository..."
    
    if [ -d "Manpower-Management-System" ]; then
        print_warning "Directory already exists. Removing old installation..."
        rm -rf Manpower-Management-System
    fi
    
    git clone https://github.com/itzSD0811/Manpower-Management-System.git
    cd Manpower-Management-System
    
    print_success "Repository cloned successfully"
}

# Install Node.js dependencies
install_dependencies() {
    print_info "Installing Node.js dependencies..."
    
    # Install frontend dependencies
    print_info "Installing frontend dependencies..."
    npm install
    
    # Install backend dependencies
    if [ -d "server" ]; then
        print_info "Installing backend dependencies..."
        cd server
        npm install
        cd ..
    fi
    
    print_success "Dependencies installed successfully"
}

# Build production version
build_application() {
    print_info "Building application for production..."
    
    npm run build
    
    if [ ! -d "dist" ]; then
        print_error "Build failed! dist directory not found"
        exit 1
    fi
    
    print_success "Application built successfully"
}

# Setup domain and SSL
setup_domain_ssl() {
    read -p "Enter your domain name (leave blank if no domain): " domain
    
    if [ -z "$domain" ]; then
        print_info "No domain provided. Skipping SSL setup."
        return
    fi
    
    read -p "Enter your email for Let's Encrypt: " email
    
    if [ -z "$email" ]; then
        print_error "Email is required for SSL certificate"
        return
    fi
    
    print_info "Setting up SSL certificate for $domain..."
    
    # Stop nginx if running
    sudo systemctl stop nginx 2>/dev/null || true
    
    # Generate SSL certificate
    sudo certbot certonly --standalone -d $domain --email $email --agree-tos --non-interactive || {
        print_error "SSL certificate generation failed"
        return
    }
    
    print_success "SSL certificate generated successfully"
}

# Configure Nginx
configure_nginx() {
    read -p "Enter your domain name (leave blank for IP access): " domain
    
    local nginx_config="/etc/nginx/sites-available/manpower-manager"
    local server_name=""
    local ssl_config=""
    
    if [ -n "$domain" ]; then
        server_name="server_name $domain;"
        
        if [ -f "/etc/letsencrypt/live/$domain/fullchain.pem" ]; then
            ssl_config="
    ssl_certificate /etc/letsencrypt/live/$domain/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$domain/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;"
        fi
    else
        server_name="server_name _;"
    fi
    
    print_info "Configuring Nginx..."
    
    if [ -n "$ssl_config" ]; then
        sudo tee $nginx_config > /dev/null <<EOF
server {
    listen 80;
    listen [::]:80;
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    ${server_name}
${ssl_config}
    
    root $(pwd)/dist;
    index index.html;
    
    location / {
        try_files \$uri \$uri/ /index.html;
    }
    
    # API proxy
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
EOF
    else
        sudo tee $nginx_config > /dev/null <<EOF
server {
    listen 80;
    listen [::]:80;
    ${server_name}
    
    root $(pwd)/dist;
    index index.html;
    
    location / {
        try_files \$uri \$uri/ /index.html;
    }
    
    # API proxy
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
EOF
    fi
    
    # Enable site
    sudo ln -sf $nginx_config /etc/nginx/sites-enabled/manpower-manager
    sudo rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true
    
    # Test and reload nginx
    sudo nginx -t && sudo systemctl reload nginx
    
    print_success "Nginx configured successfully"
}

# Create systemd service for backend
create_backend_service() {
    print_info "Creating systemd service for backend..."
    
    local service_file="/etc/systemd/system/manpower-backend.service"
    local app_dir=$(pwd)
    
    sudo tee $service_file > /dev/null <<EOF
[Unit]
Description=DNS Manpower Management System Backend
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$app_dir/server
Environment=NODE_ENV=production
ExecStart=/usr/bin/node $(which node) src/index.ts
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    
    # For TypeScript, we need to use ts-node or compile first
    if command -v ts-node &> /dev/null; then
        sudo sed -i 's|ExecStart=.*|ExecStart=/usr/bin/ts-node src/index.ts|' $service_file
    else
        print_warning "ts-node not found. Please compile TypeScript manually or install ts-node"
    fi
    
    sudo systemctl daemon-reload
    sudo systemctl enable manpower-backend.service
    
    print_success "Backend service created and enabled"
}

# Setup auto-start on boot
setup_autostart() {
    print_info "Setting up auto-start on boot..."
    
    # Enable backend service
    sudo systemctl enable manpower-backend.service
    
    # Enable nginx
    sudo systemctl enable nginx
    
    # Start services
    sudo systemctl start manpower-backend.service
    sudo systemctl start nginx
    
    print_success "Auto-start configured successfully"
}

# Main installation function
main() {
    clear
    display_credits
    
    print_info "Starting installation process..."
    
    check_root
    check_dependencies
    clone_repository
    install_dependencies
    build_application
    setup_domain_ssl
    configure_nginx
    create_backend_service
    setup_autostart
    
    print_success "Installation completed successfully!"
    echo ""
    print_info "Application is running at:"
    if [ -n "$domain" ]; then
        echo "  Frontend: https://$domain"
    else
        echo "  Frontend: http://$(hostname -I | awk '{print $1}')"
    fi
    echo "  Backend API: http://localhost:3001"
    echo ""
    print_info "Useful commands:"
    echo "  Check backend status: sudo systemctl status manpower-backend"
    echo "  Restart backend: sudo systemctl restart manpower-backend"
    echo "  View backend logs: sudo journalctl -u manpower-backend -f"
    echo ""
}

# Run main function
main "$@"

