# Quick Start Guide

## Getting Started

Extract this zip file and navigate to the extracted folder.

## One-Command Installation (Linux/Unix)

### Option 1: Bash Script (Recommended)
```bash
chmod +x install.sh
./install.sh
```

### Option 2: Python Script
```bash
chmod +x install.py
python3 install.py
```

## Windows Installation

### PowerShell Script (Recommended)
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
.\install-windows.ps1
```

### Batch Script
```cmd
install-windows.bat
```

## What You'll Be Asked

1. **Domain Name** (Optional)
   - Leave blank if you don't have a domain
   - Enter your domain if you want SSL/HTTPS

2. **Email Address** (If domain provided)
   - Required for Let's Encrypt SSL certificate
   - Used for certificate expiration notifications

## After Installation

The script will automatically:
- ✅ Install all dependencies
- ✅ Build the application
- ✅ Configure web server
- ✅ Set up SSL (if domain provided)
- ✅ Start all services
- ✅ Enable auto-start on boot

## Access Your Application

- **With Domain**: `https://your-domain.com`
- **Without Domain**: `http://your-server-ip`

## Need Help?

Check the [README.md](README.md) for detailed information and troubleshooting.

For Windows-specific instructions, see [WINDOWS_README.md](WINDOWS_README.md).

