# Windows Installation Guide

This guide will help you install and run the DNS Manpower Management System on Windows.

## Prerequisites

Before installation, make sure you have:

1. **Node.js** (v16 or higher)
   - Download from: https://nodejs.org/
   - Choose the LTS version
   - Make sure to check "Add to PATH" during installation

2. **Git**
   - Download from: https://git-scm.com/
   - Use default installation options

3. **Google Chrome** (optional but recommended)
   - The launcher will try to open Chrome automatically
   - If Chrome is not installed, it will use your default browser

## Installation Methods

### Method 1: PowerShell Script (Recommended)

1. Open PowerShell as Administrator (Right-click → Run as Administrator)
2. Navigate to where you want to install the application
3. Run the installation script:

```powershell
# Allow script execution (first time only)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Run the installer (if you have extracted this zip file)
.\install-windows.ps1
```

### Method 2: Batch Script

1. Open Command Prompt as Administrator
2. Navigate to the extracted folder
3. Run:

```cmd
install-windows.bat
```

## What the Installation Does

1. ✅ Checks for Node.js and Git
2. ✅ Clones the repository from GitHub
3. ✅ Installs all dependencies (frontend + backend)
4. ✅ Builds the application for production
5. ✅ Creates launcher scripts

## Running the Application

After installation, you have two ways to start the application:

### Option 1: Double-click `start-app.bat`
- Simple batch file launcher
- Opens two command windows (backend + frontend)
- Automatically opens Chrome

### Option 2: Run `node start-app.js`
- More reliable Node.js launcher
- Single console window
- Better process management
- Automatically opens Chrome

Both methods will:
- Start the backend server on `http://localhost:3001`
- Start the frontend server on `http://localhost:3000`
- Automatically open Chrome to `http://localhost:3000`

## Stopping the Application

- **If using start-app.bat**: Close the command windows
- **If using start-app.js**: Press `Ctrl+C` in the console window

## Troubleshooting

### "Node.js is not installed"
- Install Node.js from https://nodejs.org/
- Restart your terminal/command prompt after installation
- Verify with: `node --version`

### "Git is not installed"
- Install Git from https://git-scm.com/
- Restart your terminal/command prompt after installation
- Verify with: `git --version`

### "Chrome not found"
- The launcher will try to use your default browser
- Or manually open: `http://localhost:3000`

### "Port already in use"
- Close any other applications using ports 3000 or 3001
- Or change the ports in the configuration files

### "npm install fails"
- Make sure you have internet connection
- Try running: `npm cache clean --force`
- Then run the installer again

### PowerShell Execution Policy Error
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

## Manual Installation

If the scripts don't work, you can install manually:

1. **Clone the repository:**
   ```cmd
   git clone https://github.com/itzSD0811/Manpower-Management-System.git
   cd Manpower-Management-System
   ```

2. **Install dependencies:**
   ```cmd
   npm install
   cd server
   npm install
   cd ..
   ```

3. **Build the application:**
   ```cmd
   npm run build
   ```

4. **Start the servers:**
   ```cmd
   REM Terminal 1 - Backend
   cd server
   npm start

   REM Terminal 2 - Frontend
   npm run dev
   ```

5. **Open in browser:**
   - Navigate to: `http://localhost:3000`

## Notes

- The application runs on **localhost only** (not accessible from other devices)
- No SSL/HTTPS setup needed for local development
- No auto-start on boot (you start it manually when needed)
- All data is stored locally on your machine

## Support

For issues or questions:
- GitHub: https://github.com/itzsd0811
- Check the main README.md for more information

