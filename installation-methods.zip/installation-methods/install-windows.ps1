# DNS Manpower Management System - Windows Installation Script (PowerShell)
# Author: Sethru Dineth (ItzSD)
# GitHub: https://github.com/itzsd0811

# Check if running as Administrator
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Display credits
function Show-Credits {
    Write-Host ""
    if (Test-Path "credits.txt") {
        Get-Content "credits.txt"
    } else {
        Write-Host "========================================================" -ForegroundColor Cyan
        Write-Host "  DNS Manpower Management System" -ForegroundColor Cyan
        Write-Host "  Developed by: Sethru Dineth (ItzSD)" -ForegroundColor Cyan
        Write-Host "  GitHub: https://github.com/itzsd0811" -ForegroundColor Cyan
        Write-Host "========================================================" -ForegroundColor Cyan
    }
    Write-Host ""
    Start-Sleep -Seconds 2
}

# Check Node.js installation
function Test-NodeJS {
    Write-Host "[INFO] Checking Node.js installation..." -ForegroundColor Blue
    try {
        $nodeVersion = node --version
        Write-Host "[SUCCESS] Node.js is installed: $nodeVersion" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "[ERROR] Node.js is not installed!" -ForegroundColor Red
        Write-Host "[INFO] Please install Node.js from https://nodejs.org/" -ForegroundColor Yellow
        Write-Host "[INFO] After installation, restart PowerShell and run this script again." -ForegroundColor Yellow
        return $false
    }
}

# Check Git installation
function Test-Git {
    Write-Host "[INFO] Checking Git installation..." -ForegroundColor Blue
    try {
        $gitVersion = git --version
        Write-Host "[SUCCESS] Git is installed: $gitVersion" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "[ERROR] Git is not installed!" -ForegroundColor Red
        Write-Host "[INFO] Please install Git from https://git-scm.com/" -ForegroundColor Yellow
        Write-Host "[INFO] After installation, restart PowerShell and run this script again." -ForegroundColor Yellow
        return $false
    }
}

# Clone repository
function Clone-Repository {
    Write-Host "[INFO] Cloning repository..." -ForegroundColor Blue
    
    if (Test-Path "Manpower-Management-System") {
        Write-Host "[WARNING] Directory already exists. Removing old installation..." -ForegroundColor Yellow
        Remove-Item -Path "Manpower-Management-System" -Recurse -Force
    }
    
    git clone https://github.com/itzSD0811/Manpower-Management-System.git
    Set-Location "Manpower-Management-System"
    
    Write-Host "[SUCCESS] Repository cloned successfully" -ForegroundColor Green
}

# Install dependencies
function Install-Dependencies {
    Write-Host "[INFO] Installing Node.js dependencies..." -ForegroundColor Blue
    
    # Install frontend dependencies
    Write-Host "[INFO] Installing frontend dependencies..." -ForegroundColor Blue
    npm install
    
    # Install backend dependencies
    if (Test-Path "server") {
        Write-Host "[INFO] Installing backend dependencies..." -ForegroundColor Blue
        Set-Location "server"
        npm install
        Set-Location ".."
    }
    
    Write-Host "[SUCCESS] Dependencies installed successfully" -ForegroundColor Green
}

# Build application
function Build-Application {
    Write-Host "[INFO] Building application for production..." -ForegroundColor Blue
    
    npm run build
    
    if (-not (Test-Path "dist")) {
        Write-Host "[ERROR] Build failed! dist directory not found" -ForegroundColor Red
        exit 1
    }
    
    Write-Host "[SUCCESS] Application built successfully" -ForegroundColor Green
}

# Create launcher script
function Create-Launcher {
    Write-Host "[INFO] Creating launcher script..." -ForegroundColor Blue
    
    $launcherScript = @"
@echo off
title DNS Manpower Management System
color 0A

echo.
echo ========================================
echo   DNS Manpower Management System
echo   Starting servers...
echo ========================================
echo.

REM Get the directory where the script is located
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

REM Start backend server
echo [INFO] Starting backend server on port 3001...
start "Backend Server" cmd /k "cd server && npm start"
timeout /t 3 /nobreak >nul

REM Start frontend server
echo [INFO] Starting frontend server on port 3000...
start "Frontend Server" cmd /k "npm run dev"
timeout /t 5 /nobreak >nul

REM Open Chrome
echo [INFO] Opening application in Chrome...
start chrome.exe "http://localhost:3000"

echo.
echo [SUCCESS] Application is running!
echo   Frontend: http://localhost:3000
echo   Backend:  http://localhost:3001
echo.
echo Press any key to close this window (servers will continue running)...
pause >nul
"@
    
    $launcherScript | Out-File -FilePath "start-app.bat" -Encoding ASCII
    
    Write-Host "[SUCCESS] Launcher script created: start-app.bat" -ForegroundColor Green
}

# Create Node.js launcher (more reliable)
function Create-NodeLauncher {
    Write-Host "[INFO] Creating Node.js launcher..." -ForegroundColor Blue
    
    $launcherJS = @"
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

console.log('');
console.log('========================================');
console.log('  DNS Manpower Management System');
console.log('  Starting servers...');
console.log('========================================');
console.log('');

const scriptDir = __dirname;
const serverDir = path.join(scriptDir, 'server');
const frontendPort = 3000;
const backendPort = 3001;

// Check if server directory exists
if (!fs.existsSync(serverDir)) {
    console.error('[ERROR] Server directory not found!');
    process.exit(1);
}

// Start backend server
console.log('[INFO] Starting backend server on port', backendPort + '...');
const backend = spawn('npm', ['start'], {
    cwd: serverDir,
    shell: true,
    stdio: 'inherit'
});

// Wait a bit for backend to start
setTimeout(() => {
    // Start frontend server
    console.log('[INFO] Starting frontend server on port', frontendPort + '...');
    const frontend = spawn('npm', ['run', 'dev'], {
        cwd: scriptDir,
        shell: true,
        stdio: 'inherit'
    });
    
    // Wait for frontend to start, then open browser
    setTimeout(() => {
        console.log('[INFO] Opening application in Chrome...');
        const url = `http://localhost:` + frontendPort;
        
        // Try to open Chrome
        const chromePaths = [
            'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
            'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
            process.env.LOCALAPPDATA + '\\Google\\Chrome\\Application\\chrome.exe'
        ];
        
        let chromeFound = false;
        for (const chromePath of chromePaths) {
            if (fs.existsSync(chromePath)) {
                spawn(chromePath, [url], { detached: true, stdio: 'ignore' });
                chromeFound = true;
                break;
            }
        }
        
        if (!chromeFound) {
            // Fallback to default browser
            spawn('cmd', ['/c', 'start', url], { detached: true, stdio: 'ignore' });
        }
        
        console.log('');
        console.log('[SUCCESS] Application is running!');
        console.log('  Frontend: http://localhost:' + frontendPort);
        console.log('  Backend:  http://localhost:' + backendPort);
        console.log('');
        console.log('Press Ctrl+C to stop all servers...');
        console.log('');
    }, 5000);
}, 3000);

// Handle process termination
process.on('SIGINT', () => {
    console.log('\n[INFO] Stopping servers...');
    backend.kill();
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n[INFO] Stopping servers...');
    backend.kill();
    process.exit(0);
});
"@
    
    $launcherJS | Out-File -FilePath "start-app.js" -Encoding UTF8
    
    Write-Host "[SUCCESS] Node.js launcher created: start-app.js" -ForegroundColor Green
}

# Main installation function
function Main {
    Clear-Host
    Show-Credits
    
    Write-Host "[INFO] Starting installation process..." -ForegroundColor Blue
    Write-Host ""
    
    # Check dependencies
    if (-not (Test-NodeJS)) {
        exit 1
    }
    
    if (-not (Test-Git)) {
        exit 1
    }
    
    # Installation steps
    Clone-Repository
    Install-Dependencies
    Build-Application
    Create-NodeLauncher
    Create-Launcher
    
    Write-Host ""
    Write-Host "[SUCCESS] Installation completed successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "To start the application, run one of these:" -ForegroundColor Cyan
    Write-Host "  - Double-click: start-app.bat" -ForegroundColor Yellow
    Write-Host "  - Or run: node start-app.js" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "The application will open automatically in Chrome at http://localhost:3000" -ForegroundColor Cyan
    Write-Host ""
}

# Run main function
Main

