# DNS Manpower Management System - Installation Scripts

This package contains installation scripts for the DNS Manpower Management System.

## Available Scripts

### 1. Bash Script (`install.sh`)
A comprehensive bash script for Linux/Unix systems.

**Usage:**
```bash
chmod +x install.sh
./install.sh
```

### 2. Python Script (`install.py`)
A Python-based installation script with the same functionality.

**Usage:**
```bash
chmod +x install.py
python3 install.py
# or
./install.py
```

### Windows Scripts

#### 3. PowerShell Script (`install-windows.ps1`) - Recommended
A comprehensive PowerShell script for Windows with full automation.

**Usage:**
```powershell
# Run PowerShell as Administrator
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
.\install-windows.ps1
```

#### 4. Batch Script (`install-windows.bat`)
A simpler batch script for Windows.

**Usage:**
```cmd
# Run Command Prompt as Administrator
install-windows.bat
```

**For detailed Windows installation instructions, see [WINDOWS_README.md](WINDOWS_README.md)**

## What These Scripts Do

### Linux/Unix Scripts:

1. **Display Credits** - Shows credits from `credits.txt`
2. **Check Dependencies** - Verifies and installs required system packages
3. **Clone Repository** - Downloads the latest version from GitHub
4. **Install Dependencies** - Installs Node.js packages for frontend and backend
5. **Build Application** - Creates production-ready build
6. **Domain & SSL Setup** - Configures domain and Let's Encrypt SSL certificate (optional)
7. **Nginx Configuration** - Sets up reverse proxy and static file serving
8. **Systemd Service** - Creates auto-start service for backend
9. **Auto-Start on Boot** - Configures services to start automatically

### Windows Scripts:
1. **Display Credits** - Shows credits from `credits.txt`
2. **Check Dependencies** - Verifies Node.js and Git installation
3. **Clone Repository** - Downloads the latest version from GitHub
4. **Install Dependencies** - Installs Node.js packages for frontend and backend
5. **Build Application** - Creates production-ready build
6. **Create Launcher** - Creates `start-app.bat` and `start-app.js` launchers
7. **Auto-Open Browser** - Launchers automatically open Chrome to localhost:3000

## Requirements

### Linux/Unix:

- Linux/Unix system (Ubuntu, Debian, CentOS, etc.)
- sudo/root access
- Internet connection
- Git installed

### Windows:
- Windows 7 or higher
- Node.js (v16 or higher) - https://nodejs.org/
- Git - https://git-scm.com/
- Google Chrome (optional, for auto-launch)
- Internet connection

## Installation Process

The scripts will:
- Install missing dependencies (git, node, npm, nginx, certbot)
- Clone the repository
- Install all Node.js dependencies
- Build the production version
- Ask for domain (optional)
- Set up SSL certificate if domain provided
- Configure Nginx web server
- Create systemd service for backend
- Enable auto-start on boot

## Post-Installation

### Linux/Unix:
After installation, the application will be available at:
- **With domain**: `https://your-domain.com`
- **Without domain**: `http://your-server-ip`

Backend API will be available at: `http://localhost:3001`

### Windows:
After installation, you can start the application by:
- Double-clicking `start-app.bat`, or
- Running `node start-app.js`

The application will automatically:
- Start backend server on `http://localhost:3001`
- Start frontend server on `http://localhost:3000`
- Open Chrome browser to `http://localhost:3000`

## Useful Commands

```bash
# Check backend service status
sudo systemctl status manpower-backend

# Restart backend service
sudo systemctl restart manpower-backend

# View backend logs
sudo journalctl -u manpower-backend -f

# Check Nginx status
sudo systemctl status nginx

# Restart Nginx
sudo systemctl restart nginx
```

## Troubleshooting

### SSL Certificate Issues
If SSL certificate generation fails:
1. Ensure domain DNS points to your server
2. Ensure ports 80 and 443 are open
3. Check firewall settings

### Service Not Starting
1. Check service status: `sudo systemctl status manpower-backend`
2. View logs: `sudo journalctl -u manpower-backend -n 50`
3. Verify Node.js installation: `node --version`

### Nginx Configuration Issues
1. Test configuration: `sudo nginx -t`
2. Check error logs: `sudo tail -f /var/log/nginx/error.log`

## Notes

- The scripts require sudo access for system-level configurations
- Domain setup is optional - you can use IP address if no domain
- SSL is only configured if domain is provided
- All services are configured to start automatically on boot

